package com.example.motowidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MotoWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val views = buildViews(context)
        ids.forEach { manager.updateAppWidget(it, views) }
        schedulePeriodic(context)
    }

    override fun onEnabled(context: Context) {
        schedulePeriodic(context)
        refreshNow(context)
    }

    override fun onDisabled(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC)
    }

    companion object {
        private const val PERIODIC = "weather_periodic"
        private const val NOW = "weather_now"

        fun buildViews(ctx: Context): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget)
            views.setTextViewText(R.id.weather_text, WeatherStore.weatherText(ctx))
            views.setOnClickPendingIntent(R.id.clock_time, tap(ctx, LaunchActivity.CLOCK, 1))
            views.setOnClickPendingIntent(R.id.clock_date, tap(ctx, LaunchActivity.CALENDAR, 2))
            views.setOnClickPendingIntent(R.id.weather_text, tap(ctx, LaunchActivity.WEATHER, 3))
            return views
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MotoWidgetProvider::class.java))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, buildViews(ctx))
        }

        fun refreshNow(ctx: Context) {
            val req = OneTimeWorkRequest.Builder(WeatherWorker::class.java)
                .setConstraints(online())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniqueWork(NOW, ExistingWorkPolicy.REPLACE, req)
        }

        private fun schedulePeriodic(ctx: Context) {
            val req = PeriodicWorkRequest.Builder(WeatherWorker::class.java, 30, TimeUnit.MINUTES)
                .setConstraints(online())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        private fun online() = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        private fun tap(ctx: Context, target: String, code: Int): PendingIntent {
            val intent = Intent(ctx, LaunchActivity::class.java)
                .putExtra(LaunchActivity.EXTRA_TARGET, target)
                .setData(Uri.parse("motowidget://$target")) // keeps the three PendingIntents distinct
            return PendingIntent.getActivity(
                ctx, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
