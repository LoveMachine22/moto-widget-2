package com.example.motowidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import android.view.View
import android.widget.RemoteViews
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MotoWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED) {
            updateAll(context)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val views = buildViews(context)
        ids.forEach { manager.updateAppWidget(it, views) }
        schedulePeriodic(context)
    }

    override fun onEnabled(context: Context) {
        schedulePeriodic(context)
        refreshNow(context)
    }

    override fun onDisabled(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC)
    }

    companion object {
        private const val PERIODIC = "weather_periodic"
        private const val NOW = "weather_now"

        fun buildViews(ctx: Context): RemoteViews {
            val views = RemoteViews(ctx.packageName, R.layout.widget)

            // Weather
            val s = WeatherStore.load(ctx)
            views.setTextViewText(R.id.weather_temp, s.temp)
            views.setImageViewResource(R.id.weather_icon, iconRes(s.icon))
            views.setTextViewText(R.id.weather_condition, s.condition)
            val time = if (s.updated > 0) {
                DateFormat.getTimeFormat(ctx).format(Date(s.updated))
            } else ""
            views.setTextViewText(
                R.id.weather_place,
                listOf(s.place, time).filter { it.isNotBlank() }.joinToString(" ")
            )

            // Next alarm
            val next = ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock
            if (next != null) {
                val pattern = if (DateFormat.is24HourFormat(ctx)) "EEE HH:mm" else "EEE h:mm a"
                views.setTextViewText(
                    R.id.alarm_text,
                    SimpleDateFormat(pattern, Locale.getDefault()).format(Date(next.triggerTime))
                )
                views.setViewVisibility(R.id.alarm_row, View.VISIBLE)
            } else {
                views.setViewVisibility(R.id.alarm_row, View.GONE)
            }

            // Taps
            views.setOnClickPendingIntent(R.id.clock_time, tap(ctx, LaunchActivity.CLOCK, 1))
            views.setOnClickPendingIntent(R.id.alarm_row, tap(ctx, LaunchActivity.CLOCK, 4))
            views.setOnClickPendingIntent(R.id.clock_date, tap(ctx, LaunchActivity.CALENDAR, 2))
            views.setOnClickPendingIntent(R.id.weather_col, tap(ctx, LaunchActivity.WEATHER, 3))
            return views
        }

        private fun iconRes(key: String): Int = when (key) {
            "sun" -> R.drawable.ic_w_sun
            "moon" -> R.drawable.ic_w_moon
            "partly" -> R.drawable.ic_w_partly
            "fog" -> R.drawable.ic_w_fog
            "rain" -> R.drawable.ic_w_rain
            "snow" -> R.drawable.ic_w_snow
            "storm" -> R.drawable.ic_w_storm
            else -> R.drawable.ic_w_cloud
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MotoWidgetProvider::class.java))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, buildViews(ctx))
        }

        fun refreshNow(ctx: Context) {
            val req = OneTimeWorkRequest.Builder(WeatherWorker::class.java)
                .setConstraints(online())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniqueWork(NOW, ExistingWorkPolicy.REPLACE, req)
        }

        private fun schedulePeriodic(ctx: Context) {
            val req = PeriodicWorkRequest.Builder(WeatherWorker::class.java, 30, TimeUnit.MINUTES)
                .setConstraints(online())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        private fun online() = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        private fun tap(ctx: Context, target: String, code: Int): PendingIntent {
            val intent = Intent(ctx, LaunchActivity::class.java)
                .putExtra(LaunchActivity.EXTRA_TARGET, target)
                .setData(Uri.parse("motowidget://$target/$code"))
            return PendingIntent.getActivity(
                ctx, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
