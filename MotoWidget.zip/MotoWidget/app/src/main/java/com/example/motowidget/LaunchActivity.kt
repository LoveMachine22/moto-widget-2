package com.example.motowidget

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock

/** Invisible activity: opens the right app for the tapped widget area, then closes. */
class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.getStringExtra(EXTRA_TARGET)) {
            CLOCK -> open(
                listOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage"),
                Intent(AlarmClock.ACTION_SHOW_ALARMS)
            )
            CALENDAR -> {
                val uri = ContentUris.appendId(
                    android.provider.CalendarContract.CONTENT_URI.buildUpon().appendPath("time"),
                    System.currentTimeMillis()
                ).build()
                open(
                    listOf("com.google.android.calendar", "com.android.calendar", "com.samsung.android.calendar"),
                    Intent(Intent.ACTION_VIEW, uri)
                )
            }
            WEATHER -> openWeather()
        }
        finish()
    }

    private fun openWeather() {
        val known = listOf(
            "com.coloros.weather.service",
            "com.coloros.weather2",
            "com.oplus.weather",
            "com.oneplus.weather",
            "com.google.android.apps.weather",
            "com.sec.android.daemonapp",
            "com.miui.weather2"
        )
        if (launchPackage(known)) return

        // Last resort before the web: any launchable app with "weather" in its name
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = packageManager.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(packageManager).toString().contains("weather", ignoreCase = true)
        }
        if (match != null) {
            try {
                startActivity(
                    Intent(main).setClassName(match.activityInfo.packageName, match.activityInfo.name)
                )
                return
            } catch (e: Exception) {
            }
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather")))
        } catch (e: ActivityNotFoundException) {
        }
    }

    private fun launchPackage(packages: List<String>): Boolean {
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            try {
                startActivity(launch)
                return true
            } catch (e: ActivityNotFoundException) {
            }
        }
        return false
    }

    private fun open(packages: List<String>, fallback: Intent) {
        if (launchPackage(packages)) return
        try {
            startActivity(fallback)
        } catch (e: ActivityNotFoundException) {
        }
    }

    companion object {
        const val EXTRA_TARGET = "target"
        const val CLOCK = "clock"
        const val CALENDAR = "calendar"
        const val WEATHER = "weather"
    }
}
