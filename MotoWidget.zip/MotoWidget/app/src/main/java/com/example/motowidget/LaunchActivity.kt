package com.example.motowidget

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock

/** Invisible activity: opens the right app for the tapped widget area, then closes. */
class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.getStringExtra(EXTRA_TARGET)) {
            CLOCK -> open(
                listOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage"),
                Intent(AlarmClock.ACTION_SHOW_ALARMS)
            )
            CALENDAR -> {
                val uri = ContentUris.appendId(
                    android.provider.CalendarContract.CONTENT_URI.buildUpon().appendPath("time"),
                    System.currentTimeMillis()
                ).build()
                open(
                    listOf("com.google.android.calendar", "com.android.calendar", "com.samsung.android.calendar"),
                    Intent(Intent.ACTION_VIEW, uri)
                )
            }
            WEATHER -> open(
                listOf("com.google.android.apps.weather", "com.sec.android.daemonapp", "com.miui.weather2"),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather"))
            )
        }
        finish()
    }

    private fun open(packages: List<String>, fallback: Intent) {
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            try {
                startActivity(launch)
                return
            } catch (e: ActivityNotFoundException) {
            }
        }
        try {
            startActivity(fallback)
        } catch (e: ActivityNotFoundException) {
        }
    }

    companion object {
        const val EXTRA_TARGET = "target"
        const val CLOCK = "clock"
        const val CALENDAR = "calendar"
        const val WEATHER = "weather"
    }
}
