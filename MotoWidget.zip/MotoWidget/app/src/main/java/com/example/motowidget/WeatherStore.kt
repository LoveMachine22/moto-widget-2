package com.example.motowidget

import android.content.Context

object WeatherStore {
    private const val PREFS = "weather"

    // Used until the app has read a real location. Change these to your city.
    private const val DEFAULT_LAT = 24.8607
    private const val DEFAULT_LON = 67.0011

    // Set to true for °F
    const val USE_FAHRENHEIT = false

    class Snapshot(
        val temp: String,
        val condition: String,
        val icon: String,
        val place: String,
        val updated: Long
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveLocation(ctx: Context, lat: Double, lon: Double) {
        prefs(ctx).edit()
            .putString("lat", lat.toString())
            .putString("lon", lon.toString())
            .apply()
    }

    fun location(ctx: Context): Pair<Double, Double> {
        val p = prefs(ctx)
        val lat = p.getString("lat", null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lon = p.getString("lon", null)?.toDoubleOrNull() ?: DEFAULT_LON
        return lat to lon
    }

    fun save(ctx: Context, temp: String, condition: String, icon: String, place: String, updated: Long) {
        val p = prefs(ctx)
        // Keep the old place name if the lookup failed this time
        val keptPlace = if (place.isBlank()) p.getString("place", "") ?: "" else place
        p.edit()
            .putString("temp", temp)
            .putString("condition", condition)
            .putString("icon", icon)
            .putString("place", keptPlace)
            .putLong("updated", updated)
            .apply()
    }

    fun load(ctx: Context): Snapshot {
        val p = prefs(ctx)
        return Snapshot(
            p.getString("temp", "--°") ?: "--°",
            p.getString("condition", "") ?: "",
            p.getString("icon", "cloud") ?: "cloud",
            p.getString("place", "") ?: "",
            p.getLong("updated", 0L)
        )
    }
}
