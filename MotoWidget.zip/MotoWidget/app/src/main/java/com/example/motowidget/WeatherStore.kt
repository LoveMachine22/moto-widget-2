package com.example.motowidget

import android.content.Context

object WeatherStore {
    private const val PREFS = "weather"

    // Used until the app has read a real location. Change these to your city.
    private const val DEFAULT_LAT = 24.8607
    private const val DEFAULT_LON = 67.0011

    // Set to true for °F
    const val USE_FAHRENHEIT = false

    fun saveLocation(ctx: Context, lat: Double, lon: Double) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("lat", lat.toString())
            .putString("lon", lon.toString())
            .apply()
    }

    fun location(ctx: Context): Pair<Double, Double> {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lat = p.getString("lat", null)?.toDoubleOrNull() ?: DEFAULT_LAT
        val lon = p.getString("lon", null)?.toDoubleOrNull() ?: DEFAULT_LON
        return lat to lon
    }

    fun saveWeather(ctx: Context, text: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("text", text).apply()
    }

    fun weatherText(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("text", "…") ?: "…"
}
