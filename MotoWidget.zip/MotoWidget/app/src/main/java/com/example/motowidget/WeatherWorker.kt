package com.example.motowidget

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Fetches current weather from Open-Meteo (free, no API key). */
class WeatherWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val (lat, lon) = WeatherStore.location(applicationContext)
            val unit = if (WeatherStore.USE_FAHRENHEIT) "&temperature_unit=fahrenheit" else ""
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,is_day" +
                    "&daily=temperature_2m_max,temperature_2m_min" +
                    "&forecast_days=1&timezone=auto$unit"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            val body = try {
                conn.inputStream.bufferedReader().use { it.readText() }
            } finally {
                conn.disconnect()
            }

            val json = JSONObject(body)
            val cur = json.getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val code = cur.getInt("weather_code")
            val isDay = cur.getInt("is_day") == 1
            val daily = json.getJSONObject("daily")
            val hi = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt()
            val lo = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()

            WeatherStore.saveWeather(
                applicationContext,
                "${emoji(code, isDay)} $temp°   $hi°/$lo°"
            )
            MotoWidgetProvider.updateAll(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun emoji(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1, 2 -> if (isDay) "🌤️" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "🌨️"
        in 80..82 -> "🌧️"
        85, 86 -> "🌨️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
