package com.example.motowidget

import android.content.Context
import android.location.Geocoder
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt

/** Fetches current weather from Open-Meteo (free, no API key). */
class WeatherWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val (lat, lon) = WeatherStore.location(applicationContext)
            val unit = if (WeatherStore.USE_FAHRENHEIT) "&temperature_unit=fahrenheit" else ""
            val body = httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,is_day&timezone=auto$unit"
            )

            val cur = JSONObject(body).getJSONObject("current")
            val temp = cur.getDouble("temperature_2m").roundToInt()
            val code = cur.getInt("weather_code")
            val isDay = cur.getInt("is_day") == 1
            val symbol = if (WeatherStore.USE_FAHRENHEIT) "°F" else "°C"

            WeatherStore.save(
                applicationContext,
                "$temp$symbol",
                condition(code, isDay),
                icon(code, isDay),
                placeName(lat, lon),
                System.currentTimeMillis()
            )
            MotoWidgetProvider.updateAll(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun httpGet(address: String): String {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        return try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** Neighbourhood / city name for the coordinates. Empty if nothing could be found. */
    private fun placeName(lat: Double, lon: Double): String {
        try {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION")
                val a = Geocoder(applicationContext, Locale.getDefault())
                    .getFromLocation(lat, lon, 1)?.firstOrNull()
                val name = a?.subLocality ?: a?.locality ?: a?.subAdminArea ?: a?.adminArea
                if (!name.isNullOrBlank()) return name
            }
        } catch (e: Exception) {
        }
        try {
            val json = JSONObject(
                httpGet(
                    "https://api.bigdatacloud.net/data/reverse-geocode-client" +
                        "?latitude=$lat&longitude=$lon&localityLanguage=en"
                )
            )
            val name = json.optString("locality").ifBlank { json.optString("city") }
            if (name.isNotBlank()) return name
        } catch (e: Exception) {
        }
        return ""
    }

    private fun condition(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "Sunny" else "Clear"
        1 -> "Mainly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 71..77 -> "Snow"
        in 80..82 -> "Showers"
        85, 86 -> "Snow showers"
        in 95..99 -> "Thunderstorm"
        else -> ""
    }

    private fun icon(code: Int, isDay: Boolean): String = when (code) {
        0, 1 -> if (isDay) "sun" else "moon"
        2 -> if (isDay) "partly" else "cloud"
        3 -> "cloud"
        45, 48 -> "fog"
        in 51..57, in 61..67, in 80..82 -> "rain"
        in 71..77, 85, 86 -> "snow"
        in 95..99 -> "storm"
        else -> "cloud"
    }
}
